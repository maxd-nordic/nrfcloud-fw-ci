Full modem wired and Full modem FOTA updates can be performed using the modem firmware in CBOR image
format, provided that you have the necessary support from the nRF Connect SDK and the device
hardware. The filename is as follows:
- mfw_nrf91x1_2.0.1.cbor

This release version includes delta update from the previous firmware version. The FOTA update
filename is as follows:
- mfw_nrf91x1_update_from_2.0.0_to_2.0.1.bin

Additionally, this release includes FOTA-TEST delta update images between the original firmware and
the FOTA-TEST image. The FOTA test update filenames are as follows:
- mfw_nrf91x1_update_from_2.0.1_to_2.0.1-FOTA-TEST
- mfw_nrf91x1_update_from_2.0.1-FOTA-TEST_to_2.0.1
- mfw_nrf91x1_large_update_from_2.0.1_to_2.0.1-FOTA-TEST.bin
- mfw_nrf91x1_large_update_from_2.0.1-FOTA-TEST_to_2.0.1.bin
 
UUID of mfw_nrf91x1_2.0.1 is 9e5305b2-d7c6-4948-afe0-756a382016bf
UUID of mfw_nrf91x1_2.0.1-FOTA-TEST is 02a775b0-e29d-41cf-865f-36d1233d6ecd