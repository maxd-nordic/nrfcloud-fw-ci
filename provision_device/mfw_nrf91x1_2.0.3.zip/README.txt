Full modem wired and Full modem FOTA updates can be performed using the modem firmware in CBOR image
format, provided that you have the necessary support from the nRF Connect SDK and the device
hardware. The filename is as follows:
- mfw_nrf91x1_2.0.3.cbor

This release version includes delta update from the previous firmware version. The FOTA update
filename is as follows:
- mfw_nrf91x1_update_from_2.0.2_to_2.0.3.bin

Additionally, this release includes FOTA-TEST delta update images between the original firmware and
the FOTA-TEST image. The FOTA test update filenames are as follows:
- mfw_nrf91x1_update_from_2.0.3_to_2.0.3-FOTA-TEST
- mfw_nrf91x1_update_from_2.0.3-FOTA-TEST_to_2.0.3
- mfw_nrf91x1_large_update_from_2.0.3_to_2.0.3-FOTA-TEST.bin
- mfw_nrf91x1_large_update_from_2.0.3-FOTA-TEST_to_2.0.3.bin
 
UUID of mfw_nrf91x1_2.0.3 is 4967d395-ed7b-434a-acdc-741d1aba315e
UUID of mfw_nrf91x1_2.0.3-FOTA-TEST is f941d3b8-34e9-43ef-8012-c8796e2b8b9a